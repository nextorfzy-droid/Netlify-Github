import { panelProxy } from './_panel.mjs';
export async function handler(event) { return panelProxy(event, 'doExercises'); }
