const commonHeaders = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store, no-cache, must-revalidate, private',
  'Pragma': 'no-cache',
  'X-Content-Type-Options': 'nosniff',
  'Vary': 'Cookie, Origin'
};

export function json(statusCode, payload, extra = {}) {
  return { statusCode, headers: { ...commonHeaders, ...extra.headers }, ...(extra.multiValueHeaders ? { multiValueHeaders: extra.multiValueHeaders } : {}), body: JSON.stringify(payload) };
}

export function methodAllowed(event, method) {
  if (event.httpMethod !== method) return json(405, { ok: false, error: 'Phương thức không được hỗ trợ.' }, { headers: { Allow: method } });
  return null;
}

export function configuredUrl(name) {
  const raw = process.env[name];
  if (!raw) return { error: `Thiếu biến môi trường ${name}.` };
  let url;
  try { url = new URL(raw); } catch { return { error: `${name} không phải URL hợp lệ.` }; }
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) {
    return { error: `${name} phải sử dụng HTTPS.` };
  }
  return { url };
}

export function requestHeaders(event, contentType = 'application/json') {
  const headers = { 'Content-Type': contentType, Accept: 'application/json' };
  const cookie = event.headers?.cookie || event.headers?.Cookie;
  if (cookie) headers.Cookie = cookie;
  const userAgent = event.headers?.['user-agent'];
  if (userAgent) headers['User-Agent'] = userAgent.slice(0, 300);
  return headers;
}

export async function readJson(response) {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { upstreamMessage: 'Máy chủ OLM không trả về JSON hợp lệ.' }; }
}

export function cookiesFrom(response) {
  let cookies = [];
  if (typeof response.headers.getSetCookie === 'function') cookies = response.headers.getSetCookie();
  else {
    const one = response.headers.get('set-cookie');
    if (one) cookies = [one];
  }
  // The upstream cookie becomes a first-party cookie on this Netlify domain.
  return cookies.map((cookie) => cookie
    .replace(/;\s*Domain=[^;]*/ig, '')
    .replace(/;\s*Path=[^;]*/ig, '')
    .replace(/;\s*SameSite=[^;]*/ig, '')
    .replace(/;\s*Secure/ig, '')
    .replace(/;\s*HttpOnly/ig, '') + '; Path=/; HttpOnly; Secure; SameSite=Lax');
}

export function cookieHeaders(response) {
  const cookies = cookiesFrom(response);
  return cookies.length ? { multiValueHeaders: { 'Set-Cookie': cookies } } : {};
}

export function safeError(error) {
  // Never return upstream URLs, request bodies, or credentials to the browser.
  return json(502, { ok: false, error: 'Không kết nối được máy chủ xác thực. Hãy kiểm tra cấu hình backend và nhật ký Netlify.' });
}
