import { json, methodAllowed, configuredUrl, requestHeaders, readJson, cookieHeaders, safeError } from './_shared.mjs';

export async function handler(event) {
  const methodError = methodAllowed(event, 'POST');
  if (methodError) return methodError;
  const cfg = configuredUrl('OLM_LOGOUT_URL');
  if (cfg.error) return json(503, { ok: false, error: 'Backend chưa được cấu hình: ' + cfg.error });
  try {
    const upstream = await fetch(cfg.url, { method: 'POST', headers: requestHeaders(event), redirect: 'manual', signal: AbortSignal.timeout(12000) });
    const data = await readJson(upstream);
    const loggedOut = upstream.ok && (data.loggedOut === true || data.ok === true || data.success === true);
    if (!loggedOut) return json(502, { ok: false, error: 'Máy chủ chưa xác nhận đăng xuất.' }, cookieHeaders(upstream));
    return json(200, { ok: true, loggedOut: true }, cookieHeaders(upstream));
  } catch (error) { return safeError(error); }
}
