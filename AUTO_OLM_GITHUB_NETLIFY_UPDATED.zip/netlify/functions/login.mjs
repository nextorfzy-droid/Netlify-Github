import { json, methodAllowed, configuredUrl, requestHeaders, readJson, cookieHeaders, safeError } from './_shared.mjs';

export async function handler(event) {
  const methodError = methodAllowed(event, 'POST');
  if (methodError) return methodError;

  const origin = event.headers?.origin;
  const host = event.headers?.host;
  if (origin && host) {
    try { if (new URL(origin).host !== host) return json(403, { ok: false, error: 'Yêu cầu không cùng nguồn.' }); }
    catch { return json(403, { ok: false, error: 'Nguồn yêu cầu không hợp lệ.' }); }
  }

  const cfg = configuredUrl('OLM_LOGIN_URL');
  if (cfg.error) return json(503, { ok: false, error: 'Backend chưa được cấu hình: ' + cfg.error });

  let params;
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
    if (raw.length > 12000) return json(413, { ok: false, error: 'Dữ liệu gửi lên quá lớn.' });
    params = new URLSearchParams(raw);
  } catch { return json(400, { ok: false, error: 'Dữ liệu đăng nhập không hợp lệ.' }); }

  const username = (params.get('username') || '').trim();
  const password = params.get('password') || '';
  if (!username || !password || username.length > 256 || password.length > 1024) {
    return json(400, { ok: false, error: 'Vui lòng kiểm tra tên đăng nhập và mật khẩu.' });
  }

  try {
    const upstream = await fetch(cfg.url, {
      method: 'POST',
      headers: requestHeaders(event, 'application/x-www-form-urlencoded;charset=UTF-8'),
      body: new URLSearchParams({ username, password }),
      redirect: 'manual',
      signal: AbortSignal.timeout(15000)
    });
    const data = await readJson(upstream);
    const authenticated = upstream.ok && (data.authenticated === true || data.ok === true || data.success === true);
    if (!authenticated) {
      const message = typeof data.message === 'string' ? data.message.slice(0, 240) : 'Thông tin đăng nhập không hợp lệ hoặc máy chủ chưa xác nhận phiên.';
      return json(upstream.status >= 500 ? 502 : 401, { ok: false, authenticated: false, error: message }, cookieHeaders(upstream));
    }
    return json(200, { ok: true, authenticated: true, message: 'Đăng nhập thành công.' }, cookieHeaders(upstream));
  } catch (error) {
    return safeError(error);
  }
}
