import { json, methodAllowed, configuredUrl, requestHeaders, readJson, safeError } from './_shared.mjs';

export async function handler(event) {
  const methodError = methodAllowed(event, 'GET');
  if (methodError) return methodError;
  const cfg = configuredUrl('OLM_SESSION_URL');
  if (cfg.error) return json(503, { ok: false, authenticated: false, error: 'Chưa cấu hình kiểm tra phiên.' });
  try {
    const upstream = await fetch(cfg.url, { method: 'GET', headers: requestHeaders(event), redirect: 'manual', signal: AbortSignal.timeout(10000) });
    const data = await readJson(upstream);
    const authenticated = upstream.ok && data.authenticated === true;
    return json(200, { ok: true, authenticated });
  } catch (error) { return safeError(error); }
}
