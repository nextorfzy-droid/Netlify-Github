import { json, configuredUrl, requestHeaders, readJson, safeError } from './_shared.mjs';

const ROUTES = {
  exercises: { env: 'OLM_EXERCISES_URL', method: 'POST' },
  doExercises: { env: 'OLM_DO_EXERCISES_URL', method: 'POST' },
  answers: { env: 'OLM_GET_ANSWERS_URL', method: 'POST' }
};

export async function panelProxy(event, key) {
  const route = ROUTES[key];
  if (!route) return json(404, { ok: false, error: 'API không tồn tại.' });
  if (event.httpMethod !== route.method) return json(405, { ok: false, error: 'Phương thức không được hỗ trợ.' }, { headers: { Allow: route.method } });

  const origin = event.headers?.origin;
  const host = event.headers?.host;
  if (origin && host) {
    try { if (new URL(origin).host !== host) return json(403, { ok: false, error: 'Yêu cầu không cùng nguồn.' }); }
    catch { return json(403, { ok: false, error: 'Nguồn yêu cầu không hợp lệ.' }); }
  }
  const cookie = event.headers?.cookie || event.headers?.Cookie;
  if (!cookie) return json(401, { ok: false, error: 'Bạn cần đăng nhập lại trước khi sử dụng chức năng này.' });

  const cfg = configuredUrl(route.env);
  if (cfg.error) return json(503, { ok: false, error: `Backend chưa được cấu hình (${route.env}).` });

  let payload;
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
    if (raw.length > 100000) return json(413, { ok: false, error: 'Dữ liệu gửi lên quá lớn.' });
    payload = raw ? JSON.parse(raw) : {};
  } catch { return json(400, { ok: false, error: 'JSON gửi lên không hợp lệ.' }); }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return json(400, { ok: false, error: 'Dữ liệu yêu cầu không hợp lệ.' });

  try {
    const headers = requestHeaders(event, 'application/json');
    for (const h of ['x-csrf-token', 'x-xsrf-token', 'x-requested-with', 'referer', 'origin']) {
      if (event.headers?.[h]) headers[h] = event.headers[h];
    }
    const upstream = await fetch(cfg.url, {
      method: 'POST', headers, body: JSON.stringify(payload), redirect: 'manual',
      signal: AbortSignal.timeout(20000)
    });
    const data = await readJson(upstream);
    if (!upstream.ok) return json(upstream.status >= 500 ? 502 : upstream.status, {
      ok: false, success: false,
      error: typeof data.message === 'string' ? data.message.slice(0, 300) : 'Máy chủ bài tập từ chối yêu cầu.'
    });
    return json(200, data);
  } catch (error) { return safeError(error); }
}
